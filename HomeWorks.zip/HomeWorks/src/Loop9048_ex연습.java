public class Loop9048_ex연습 {
    public static void main(String[] args) {
        //1부터 20까지의 홀수를 차례대로 출력하는 프로그램을 작성하시오.

        for (int i = 1; i < 21; i++) {
            if(i%2==1){
                System.out.println(i+" ");
            }


        }
    }
}
