public class Loop536_self1자가 {
    public static void main(String[] args) {
        int a = 0;
        while (a<15){
            a++;
            System.out.print(a+" ");
        }

    }
}
