import java.util.Scanner;

public class Loop9046_ex연습 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        for (int i = 0; i < a; i++) {
            System.out.println("C언어 프로그래밍");

        }

    }
}
