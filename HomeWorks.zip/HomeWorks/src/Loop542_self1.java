public class Loop542_self1 {
    public static void main(String[] args) {
        //10부터 20까지의 숫자를 차례대로 출력하는
        // 프로그램을 작성하시오.for문을 사용하세요.
        for (int i = 0; i <= 10; i++) {
            System.out.print((i+10)+" ");

        }

    }
}
