import javax.swing.*;

public class Loop9047_ex연습 {
    public static void main(String[] args) {
        //대문자를 'A'부터 'Z'까지 차례로 출력하는 프로그램을 작성하시오.
        for (int i = 65; i <= 90; i++) {
            char a = (char)i;
            System.out.print(a);

        }


    }
}
