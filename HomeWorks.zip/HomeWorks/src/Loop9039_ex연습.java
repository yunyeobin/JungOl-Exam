public class Loop9039_ex연습 {
    public static void main(String[] args) {

        for (char characterValue = 'A'; characterValue <= 'Z'; characterValue++) {
            System.out.printf("%c", characterValue);
            System.out.println((int)characterValue);
        }


    }
}
